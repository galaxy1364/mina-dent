
# CI Run Evidence

## Unsigned / Previous CI (reference)
Workflow Run: https://github.com/galaxy1364/mina-dent/actions/runs/20529522279  
Digest (sha256): sha256:0819c2a8679397ffd06214e83f7a020f201d173e388b70acc12900ab18f0dfda

## Signed CI (Attested)
Signed Workflow Run (attempt): https://github.com/galaxy1364/mina-dent/actions/runs/20530811703/attempts/2  
Attestation: https://github.com/galaxy1364/mina-dent/attestations/15725923  
Signed Subject: evidence.tgz  
Signed Subject Digest (sha256): sha256:998d620b8ac5cb02a382410c724f82814042beaa209e26294abb62c5b7725f175  
Signed Artifact Digest (sha256): sha256:0b5345042a4dc28c64b1a5165f4484dd6b64d511fc1895e7cb51b6c4d84aa96b


